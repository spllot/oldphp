<?php
?>
<html>
	<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title></title>
	</head>
<LINK href="../css/index_admin.css" rel="stylesheet" type="text/css">
<body>
<table cellpadding="0" cellspacing="0" width="100%" height="100%" border="0">
	<tr>
		<td align="center" valign="center">
			<table class="main">
				<tr>
					<td class="banner_bg" style="vertical-align:middle">
		<table style="height:90px; width:100%" border="0">
			<tr>
				<td style="width:30px">&nbsp;</td>
				<td style="background1:white; text-align1:center; width1:250px;padding1:5px; filter1: Alpha(Opacity=50);">
					
				</td>
				<td style="width:px">&nbsp;</td>
			</tr>
		</table>
					</td>
				</tr>
				<tr>
					<td class="content_bg">
						<table width="100%" border="0" height="100%">
							<tr><form action="login_go.php" method="post" name="login">
								<td class="leftblock">
                                    <table>
                                        <tr><td class="filter">
									<table class="login">
										<tr>
											<td nowrap class="label">帳號：</td>
											<td><input name="userid" type="text" style="width:120px"></td>
										</tr>
										<tr>
											<td align="right" class="label">密碼：</td>
											<td><input name="passwd" type="password" style="width:120px"></td>
										</tr>
										<tr>
											<td colspan="2" align="center">
												<table width="40%"  border="0" cellspacing="0" cellpadding="3">
													<tr>
														<td align="center"><input type="reset" class="command" value="取消"></td>
														<td align="center"><input type="button" class="command" value="登入" onClick="login.submit();"></td>
													</tr>
												</table>
											</td>
										</tr>
									</table>
                                        </td>
                                    </tr>
                                </table>
								</td>
								<td class="rightblock">
								</td>
								</form>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td class="footer_bg">
						<table width="100%" height="100%">
							<tr>
								<td class="footer">
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
</body>
</html>