<?php
$usefors = array(
	'PRODUCT1'		=>	'到店團購',
	'PRODUCT2'		=>	'宅配團購',
	'PRODUCT4'		=>	'到店廉售',
	'PRODUCT5'		=>	'宅配廉售',
	);
?>