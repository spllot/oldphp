<?php
?>
<HTML>
<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<TITLE></TITLE>
<frameset rows="100,*" border="0" framespacing="0">
	<frame src="banner.php" name="banner" marginwidth="0" marginheight="0" frameborder="NO" scrolling="NO" NORESIZE>
	<frame src="display.php" name="display" marginwidth="0" marginheight="0" frameborder="NO" scrolling="NO" NORESIZE>
</frameset>
</HEAD>
<BODY>
本網頁使用 Frame 設計，而您的瀏覽器並不支援
</BODY>
</HTML>