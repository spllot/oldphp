<?php
$usefors = array(
	'BANNER'		=>	'橫幅廣告',
	'SLIDE'			=>	'首頁輪播廣告',
	);
?>