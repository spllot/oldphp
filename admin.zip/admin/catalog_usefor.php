<?php
$usefors = array(
	'TYPE_AREA'		=>	'地區', 
	'TYPE_COM'		=>	'消費類型',
	'TYPE_PRO'		=>	'商品分類',
	'TYPE_TPT'		=>	'運輸分類',
	'TYPE_JOB'		=>	'人力分類',
	'TYPE_ACT'		=>	'活動分類',
	);
?>