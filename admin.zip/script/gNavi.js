$(document).ready(function(){

  $("#global_navi").treeview({
  		animated: "medium",
		collapsed: true,
		unique: true
	});

});
